import React from 'react';

const ProdctActualSize = () => {
  return (
    <>
      <h3>실측사이즈</h3>
      <img style={{ width: '80%' }} src="../../images/actual-size.jpg" alt="실측 사이즈" />
    </>
  );
};

export default ProdctActualSize;
