import React from 'react';
import { Outlet } from 'react-router-dom';

const Brand = () => {
  return <Outlet />;
};

export default Brand;
